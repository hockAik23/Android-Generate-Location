package com.example.locationgenerator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ResultReceiver;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class MainActivity extends AppCompatActivity implements com.google.android.gms.location.LocationListener{
    private static final int LOCATION_CODE = 1;
    TextView longitude;
    TextView latitude;
    EditText address;
    Button generate;
    //location
    LocationManager locationManager;
    FusedLocationProviderClient client;
    ProgressBar progressBar;
    ResultReceiver resultReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultReceiver = new AddressResultReceiver(new Handler());
        longitude = findViewById(R.id.longitude);
        latitude = findViewById(R.id.latitude);
        address = findViewById(R.id.address);
        generate = findViewById(R.id.generate);
        progressBar = findViewById(R.id.progressBar);
        client = LocationServices.getFusedLocationProviderClient(this);

        generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(ContextCompat.checkSelfPermission(
                  getApplicationContext(), ACCESS_FINE_LOCATION
               ) != PackageManager.PERMISSION_GRANTED){
                   ActivityCompat.requestPermissions(
                           MainActivity.this, new String[]{ACCESS_FINE_LOCATION},
                           LOCATION_CODE
                   );
               }else{
                   getCurrentLocation();
               }
            }
        });

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == LOCATION_CODE && grantResults.length > 0){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                getCurrentLocation();
            }else{
                Toast.makeText(this,"Permission Denied.", Toast.LENGTH_LONG).show();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
    private void getCurrentLocation() {
      //  progressBar.setVisibility(View.VISIBLE);
        final LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(3000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationServices.getFusedLocationProviderClient(MainActivity.this)
                .requestLocationUpdates(locationRequest, new LocationCallback(){
                   @Override
                   public void onLocationResult(LocationResult locationResult){
                       super.onLocationResult(locationResult);
                       LocationServices.getFusedLocationProviderClient(MainActivity.this)
                               .removeLocationUpdates(this);
                       if(locationResult != null && locationResult.getLocations().size() >0){
                           int latestLocationIndex = locationResult.getLocations().size() - 1;
                           double latitudes = locationResult.getLocations().get(latestLocationIndex).getLatitude();
                           double longitudes = locationResult.getLocations().get(latestLocationIndex).getLongitude();

                         latitude.setText(String.format("Latitude: %s\nLongitude: %s",latitudes,longitudes));
                           //latitude.setText((int) latitudes);
                           //longitude.setText((int) longitudes);
                           Location location = new Location("providerNA");
                           location.setLatitude(latitudes);
                           location.setLongitude(longitudes);
                           fetchAddressFromLatLong(location);
                       }else{
                      // progressBar.setVisibility(View.GONE);
                       }
                   }
                }, Looper.getMainLooper());
    }

    private void fetchAddressFromLatLong(Location location){
        Intent intent = new Intent(MainActivity.this, FetchAddressLocation.class);
        intent.putExtra(Constants.RECEIVER, resultReceiver);
        intent.putExtra(Constants.LOCATION_DATA_EXTRA, location);
        startService(intent);
    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onLocationChanged(Location location) {

    }
    private class AddressResultReceiver extends ResultReceiver{
        AddressResultReceiver(Handler handler) {
            super(handler);
        }
        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData){
            super.onReceiveResult(resultCode,resultData);
            if(resultCode == Constants.SUCCESS_RESULT){
                address.setText(resultData.getString(Constants.RESULT_DATA_KEY));
            }else{
                Toast.makeText(MainActivity.this,resultData.getString(Constants.RESULT_DATA_KEY),Toast.LENGTH_LONG).show();
            }
        }
    }
}
